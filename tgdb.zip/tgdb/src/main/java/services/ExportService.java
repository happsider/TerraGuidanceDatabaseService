package services;
import models.Well;
import java.sql.Connection;
import java.sql.SQLException;
import exceptions.DatabaseConnectionException;
import utilities.DatabaseUtilities;

import writing.*;

public class ExportService {
	//send data to database
	public static void exportData(Well well, boolean[] check, String[] people, String csv) 
			throws DatabaseConnectionException, SQLException 
	{	
		Connection connection = DatabaseUtilities.connect();
		try {
			
			if(check[0]) {
				//EXPORT WELL DATA
				WellWriter.uploadWellData(well, connection, csv);
				//EXPORT PEOPLE TO WELL
				PeopleOnWellWriter.uploadPeopleToWell(well, people, csv, connection); }
			if(check[1])
				//EXPORT WELL LOG DATA
				LogWriter.uploadLogData(connection, csv);
			if(check[2])
				//EXPORT SURVEY DATA
				SurveyWriter.uploadSurveyData(connection, csv);
			
			System.out.println("Export Complete!");
			
		} catch(Exception e) { e.getMessage(); }
		finally { 
			try {connection.close();} catch (Exception e) { e.getMessage(); } }
	}
}

