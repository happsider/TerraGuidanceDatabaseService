package services;
import java.io.IOException;
import utilities.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//import com.opencsv.exceptions.CsvValidationException;

import exceptions.DatabaseConnectionException;

import writing.LogWriter;
import writing.WellWriter;
import models.*;
public class ImportService {

	public String getInfo() {return HttpRequest.getConnection();}
	public void importData() throws DatabaseConnectionException, SQLException
	{
		Connection connection = DatabaseUtilities.connect();
		try {
			String queryString = "select * from WellRepository.well;";
			PreparedStatement stmt = connection.prepareStatement(queryString);
			
			stmt.executeUpdate();	
			
		} catch(Exception e) {
			e.getMessage();
		}
		finally
		{
			connection.close();
		}
	}
}

