package utilities;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.ibatis.common.jdbc.ScriptRunner;

import exceptions.DatabaseConnectionException;
import exceptions.DatabaseInitializationException;

public class DatabaseUtilities {

    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://148.72.59.83:3306/WellRepository";


    private static final String USER = "jefflacy";
    private static final String PASSWORD = "oilANDgas2020";
    
    public static Connection connect() throws DatabaseConnectionException {
    	Connection connection = null;
    	try 
    	{
    		Class.forName(JDBC_DRIVER);
    		connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
    	} 
    	 catch (ClassNotFoundException  |SQLException e) 
    	{
    		throw new DatabaseConnectionException("Could not connect to the database."+e.getMessage(), e);
    	}
    	return connection;
    }
    
    public static void initializeDatabase(String initializationScript) throws DatabaseInitializationException {

        Connection connection;// = null;
        try {
            connection = connect();
            ScriptRunner runner = new ScriptRunner(connection, false, false);
            InputStream inputStream = new  FileInputStream(initializationScript);

            InputStreamReader reader = new InputStreamReader(inputStream);
            
            runner.runScript(reader);
            reader.close();
            connection.commit();
            connection.close();

        } catch (DatabaseConnectionException | SQLException |IOException e) {
           throw new DatabaseInitializationException("Could not initialize db because of:"
                   + e.getMessage(),e);
        }

    }
}
