package utilities;
import services.*;
import models.Well;
public class Application {
/*
	public static void runProgram(String csv) 
		{			    
			try {ExportService.exportData(new Well(), csv); }
			catch(Exception e) { e.getMessage(); }
		}
*/
}