package writing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import models.Surveys;

public class SurveyWriter {
	public static Surveys parseFile(String csv) throws IOException
	{
	    Scanner scanner = new Scanner(new File(csv));
	    String api = "";
		Surveys surveys = new Surveys();
	    //Set the delimiter used in file
	    scanner.useDelimiter(",");
	    api = scanner.next();
	    scanner.nextLine();


	    int columnNum = 0;

		while (scanner.hasNext())
			if(scanner.next().equals("Index"))
				break;
			else columnNum++;


		Scanner dataGetter = new Scanner(new File(csv));
		dataGetter.useDelimiter(",");
		dataGetter.nextLine();
		dataGetter.nextLine();
		dataGetter.nextLine();
		
		Scanner indexCheck = new Scanner(new File(csv));
		indexCheck.useDelimiter(",");
		indexCheck.nextLine();
		indexCheck.nextLine();
		indexCheck.nextLine();
	    
		int lastIndex = -1, thisIndex = 0;
	    
		List<Double> md = new ArrayList<>();
		List<Double> inc = new ArrayList<>();
		List<Double> azi = new ArrayList<>();
		


		while (scanner.hasNextLine())
	    {
			try {
				lastIndex = thisIndex;
				thisIndex = getSurveyIndex(indexCheck, columnNum);
			}catch(Exception e) {break;}
			
	    	if (lastIndex < thisIndex)
	    	{	
	    		surveys.setApi(api);

	    		md.add(Double.parseDouble(dataGetter.next()));
	    		inc.add(Double.parseDouble(dataGetter.next()));
	    		azi.add(Double.parseDouble(dataGetter.next()));
	    	}  	
		    	indexCheck.nextLine();
		    	dataGetter.nextLine();
	    }

		surveys.setMd(md);
		surveys.setInc(inc);
		surveys.setAzi(azi);

	    scanner.close();
	    
	    return surveys;
	}
	
	
	private static int getSurveyIndex(Scanner scan, int columnNum)
	{
		scan.useDelimiter(",");
		
		String val = "";
		
		for (int i = 0; i <= columnNum; i++)
			val = (scan.next());

		return Integer.parseInt(val);
	}
	
	public static void uploadSurveyData(Connection connection, String csv) 
			throws SQLException, IOException
	{
		Surveys surveys = new Surveys();
		surveys = parseFile(csv);

		String query = "insert into surveys (well_API, md, inc, azi) values ";
	
		String api = "", name = "";
		String finalQuery = query;
	
		System.out.println("Generating Survey Query...");
		int i = 0;
		for(Double depth : surveys.getMd())
		{
			api = surveys.getApi();
			
			query = "(\"" + api + "\",\"" + depth + "\","
					+ surveys.getInc().get(i) + "," + 
					surveys.getAzi().get(i)+"),";
			
			if(i == surveys.getMd().size()-1)
				query = query.substring(0,query.length()-1) + ";";
			
			i++;
		
			finalQuery = finalQuery.concat(query);		
		}
		
		System.out.println("Updating Survey Data to Database...");
		PreparedStatement stmt = connection.prepareStatement(finalQuery);
		
		stmt.executeUpdate();
		System.out.println("Surveys Updated");

	}
}
