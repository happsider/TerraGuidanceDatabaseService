package writing;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import models.Person;
import models.Well;

public class PeopleOnWellWriter {
	private static List<Person> people = new ArrayList<>();
	
	public static void uploadPeopleToWell(Well well, String[] peopleString, String csv, Connection connection)
	{
		try
		{
			well = WellWriter.parseFile(well, csv);
			fillPeopleList(peopleString);
			String fullQuery = "insert into people_on_well (well_api, person_name) values ";
			String query = "";
			PreparedStatement stmt;
			if(people.size()>0)
			{

					int i = 0;
					
				for(Person person : people)
				{
					query = "(\"" + well.getApi() + "\",\"" + person.getFirstName() + " "
							+ person.getLastName() +"\"),";
					
					if(i == people.size()-1)
						query = query.substring(0,query.length()-1) + ";";
				
					i++;
					fullQuery = fullQuery.concat(query);		
				}
	
					System.out.println(fullQuery);
					stmt = connection.prepareStatement(fullQuery);
					stmt.executeUpdate();
			}
				
		} catch (SQLException | IOException e) {e.printStackTrace();} 		
	}
	private static void fillPeopleList(String[] peopleString)
	{
		for (String person : peopleString)
			if (person.isEmpty())
				continue;
			else 
			{ 
				Person tempPerson = new Person();
				String[] name = person.split(" ");
				tempPerson.setFirstName(name[0]);
				tempPerson.setLastName(name[1]);
				System.out.println("First Name: " + tempPerson.getFirstName() + ", Last Name: " + tempPerson.getLastName());
				people.add(tempPerson);		
			}
		
	}
}
