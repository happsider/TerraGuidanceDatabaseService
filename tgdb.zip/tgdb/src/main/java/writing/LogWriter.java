package writing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import models.Logs;

public class LogWriter {
	public static List parseFile(String csv) throws IOException
	{
	    Scanner scanner = new Scanner(new File(csv));
	    List<Logs> listOfLogs = new ArrayList<>();
	    String api = "";
	    //Set the delimiter used in file
	    scanner.useDelimiter(",");
	    api = scanner.next();
	    scanner.nextLine();
	    
	    int columnNum = 0;
		int numOfLogs = 0;
	    while (scanner.hasNext())
	    {
	    	if (scanner.next().equalsIgnoreCase("Log"))
	    	{	
	    		//******GET LOG NAME********
	    		Logs logs = new Logs();
	    		logs.setName(getName(2, csv, columnNum));
	    		logs.setApi(api);
	    		//******GET DATA************
	    		List<Double> md = new ArrayList<>();
	    		List<Double> data = new ArrayList<>();
	    		Scanner dataGetter = new Scanner(new File(csv));
	    		dataGetter.useDelimiter(",");
	    		
	    		dataGetter.nextLine(); //to Category
	    		dataGetter.nextLine(); //to ColName
	    		dataGetter.nextLine(); //to actual data

	    		while(dataGetter.hasNextLine())
	    		{
	    			md.add(Double.parseDouble(dataGetter.next()));
	    			data.add(Double.parseDouble(getData(dataGetter, columnNum-1)));
	    			dataGetter.nextLine();
	    		}
	    		  		
	    		logs.setMd(md);
	    		logs.setData(data);
	    		listOfLogs.add(logs);
	    		//iterate to next log
	    		numOfLogs++;
	    		columnNum++;
	    	}
	    	else if(numOfLogs > 0)
	    		//number of logs won't be greater than 0 until the first 'if' block is reached.
	    		break;
	    	else
	    		columnNum++;    	
	    }
	    scanner.close();   
	    return listOfLogs;
	}
	
	private static String getName(int rowNum, String csv, int columnNum) throws IOException
	{
		Scanner scan = new Scanner(new File(csv));
		String value = null;
		scan.useDelimiter(",");
		//get row
		for (int i = 0; i < rowNum; i++) scan.nextLine();
		//get column
		for (int i = 0; i <= columnNum; i++) value = scan.next();

		//System.out.println ("Data Value: " + value);
		return value;
	}
	
	private static String getData(Scanner scan, int columnNum) throws FileNotFoundException
	{
		scan.useDelimiter(",");
		String value = null;
		for (int i = 0; i <= columnNum; i++) value = scan.next();
		return value;
	}
	
	public static void uploadLogData(Connection connection, String csv) 
			throws SQLException, IOException
	{
		List<Logs> listOfLogs = new ArrayList<>();
		List<String> queryString = new ArrayList<>();
		listOfLogs = LogWriter.parseFile(csv);
		String query = "insert into logs (well_API, log_name, md, `data`) values ";
	
		String api = "", name = "";
		String finalQuery = query;
	
		System.out.println("Generating Log Query...");
		int j = 0;
		for(Logs log : listOfLogs)
		{
			api = log.getApi();
			name = log.getName();
			int i = 0;
			for(double depth : log.getMd())
			{
				query = "(\"" + api + "\",\"" + name + "\","
						+ depth + "," + log.getData().get(i)+"),";
				
				if(i == log.getMd().size()-1 && j == listOfLogs.size()-1)
					query = query.substring(0,query.length()-1) + ";";
			
				i++;
				finalQuery = finalQuery.concat(query);		
			}
			j++;
		}
		System.out.println("Updating Log Data to Database...");
		PreparedStatement stmt = connection.prepareStatement(finalQuery);
		
		stmt.executeUpdate();
		System.out.println("Logs Updated");

	}
	
}