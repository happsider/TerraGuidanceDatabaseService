package writing;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

//import com.opencsv.CSVReader;
//import com.opencsv.exceptions.CsvValidationException;

import models.Well;

public class WellWriter{
	public static Well parseFile(Well well, String csv) throws IOException
	{
	    Scanner scanner = new Scanner(new File(csv));
	    
	    //Set the delimiter used in file
	    scanner.useDelimiter(",");

    	well.setApi(scanner.next());
    	well.setVsAzi(Double.parseDouble(scanner.next()));
    	well.setWellName(scanner.next());
    	scanner.next(); //Client
    	well.setKb(Double.parseDouble(scanner.next()));
    	well.setxSurf(Double.parseDouble(scanner.next()));
    	well.setySurf(Double.parseDouble(scanner.next()));	
    	
	    scanner.close();
	    
	    return well;
	}
	public static void uploadWellData(Well well, Connection connection, String csv)
	{
		try
		{
			well = WellWriter.parseFile(well, csv);
			String queryString = "insert ignore into well (API, well_name, " 
					+ "vs_azi, kb, X_surf, Y_surf, Lat, `Long`, target_fm, service_type,"
					+ "rig_name) values (\"" +
					well.getApi() 		+  "\",\"" +
					well.getWellName()  +  "\"," +
					well.getVsAzi()		+  "," +
					well.getKb()		+  "," +
					well.getxSurf()     +  "," +
					well.getySurf()     +  "," +
					well.getLati()      +  "," +
					well.getLongi()     +  ",\"" +
					well.getFormation().getFmName() +  "\",\"" +
					well.getService()     +  "\",\"" +
					well.getRigName()     +  "\"); ";
			PreparedStatement stmt = connection.prepareStatement(queryString);
			
			stmt.executeUpdate();
			System.out.println(well.getWellName() + " Uploaded to Database");
		} catch (Exception e) {e.getMessage();}
		

	}
}
