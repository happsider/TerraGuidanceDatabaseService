package window;

import models.Well;
import services.ExportService;
import models.Formation;

import java.util.Timer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import utilities.Application;
import writing.PeopleOnWellWriter;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.ProgressBar;
public class AdditionalWellInfo {

	protected Shell shlDatabaseUpload;
	private Text txtAnalyst1;
	private Text txtAnalyst2;
	private Text txtAnalyst3;
	private Text ShlLat;
	private Text txtShlLong;
	private Text txtBhlLat;
	private Text txtBhlLong;
	private Text txtFormation;
	private Label lblAnalyst;
	private Label lblAnalyst_1;
	private Label lblServices;
	private Label lblOnsite;
	private Label lblRemote;
	private Button btnOnsiteGeosteering;
	private Button btnRemoteGeosteering;
	private Button btnMudLogging;
	private Label lblRigName;
	private Text txtRigName;
	private Button btnUpload;
	private Label lblUploadAdditionalWell;
	private Button btnCancel;
	private Label lblBeSureApi;
	private Label label;
	private Label lblState;
	private Label lblCounty;
	private Label lblCountry;
	private Label lblBasin;
	private Label lblField;
	private Text txtCountry;
	private Text txtStateProvince;
	private Text txtCounty;
	private Text txtBasin;
	private Text txtField;
	private Label lblGeologist;
	private Text txtGeologist;
	private Label lblPleaseNoteThat;
	private Label label_1;
	private Label label_2;
	private Button chkUploadSurveys;
	private Label lblUploadOptions;
	private Button chkUploadLogs;
	private Button chkUploadWellInfo;
	private Label label_3;
	private Label lblUpdateInfo;
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			AdditionalWellInfo window = new AdditionalWellInfo();
			window.open();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlDatabaseUpload.open();
		shlDatabaseUpload.layout();
		while (!shlDatabaseUpload.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlDatabaseUpload = new Shell();
		shlDatabaseUpload.setMinimumSize(new Point(585, 1175));
		shlDatabaseUpload.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		shlDatabaseUpload.setSize(277, 578);
		shlDatabaseUpload.setText("Database Upload");
		shlDatabaseUpload.setLayout(new GridLayout(4, false));
		
				lblUploadAdditionalWell = new Label(shlDatabaseUpload, SWT.NONE);
				lblUploadAdditionalWell.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
				lblUploadAdditionalWell.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
				lblUploadAdditionalWell.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 4, 1));
				lblUploadAdditionalWell.setText("Upload Additional Well Information");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblPleaseNoteThat = new Label(shlDatabaseUpload, SWT.NONE);
		lblPleaseNoteThat.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		lblPleaseNoteThat.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.ITALIC));
		lblPleaseNoteThat.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 3, 1));
		lblPleaseNoteThat.setText("Please note that all entries are optional");
		
		label_1 = new Label(shlDatabaseUpload, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_1.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		label_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		GridData gd_label_1 = new GridData(SWT.FILL, SWT.CENTER, false, false, 4, 1);
		gd_label_1.widthHint = 252;
		label_1.setLayoutData(gd_label_1);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		Label lblNewLabel = new Label(shlDatabaseUpload, SWT.NONE);
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblNewLabel.setText("Target Formation");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtFormation = new Text(shlDatabaseUpload, SWT.BORDER);
		txtFormation.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		GridData gd_txtFormation = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtFormation.widthHint = 150;
		txtFormation.setLayoutData(gd_txtFormation);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		Label lblAnalyst1 = new Label(shlDatabaseUpload, SWT.NONE);
		lblAnalyst1.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblAnalyst1.setText("TG Analyst 1");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtAnalyst1 = new Text(shlDatabaseUpload, SWT.BORDER);
		txtAnalyst1.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		GridData gd_txtAnalyst1 = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtAnalyst1.widthHint = 150;
		txtAnalyst1.setLayoutData(gd_txtAnalyst1);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblAnalyst = new Label(shlDatabaseUpload, SWT.NONE);
		lblAnalyst.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblAnalyst.setText("TG Analyst 2");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtAnalyst2 = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtAnalyst2 = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtAnalyst2.widthHint = 150;
		txtAnalyst2.setLayoutData(gd_txtAnalyst2);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblAnalyst_1 = new Label(shlDatabaseUpload, SWT.NONE);
		lblAnalyst_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblAnalyst_1.setText("TG Analyst 3");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtAnalyst3 = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtAnalyst3 = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtAnalyst3.widthHint = 150;
		txtAnalyst3.setLayoutData(gd_txtAnalyst3);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblGeologist = new Label(shlDatabaseUpload, SWT.NONE);
		lblGeologist.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblGeologist.setText("Geologist");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtGeologist = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtGeologist = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtGeologist.widthHint = 150;
		txtGeologist.setLayoutData(gd_txtGeologist);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblRigName = new Label(shlDatabaseUpload, SWT.NONE);
		lblRigName.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblRigName.setText("Rig Name");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtRigName = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtRigName = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtRigName.widthHint = 150;
		txtRigName.setLayoutData(gd_txtRigName);
		
		label = new Label(shlDatabaseUpload, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		GridData gd_label = new GridData(SWT.FILL, SWT.FILL, false, false, 4, 1);
		gd_label.widthHint = 244;
		label.setLayoutData(gd_label);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblCountry = new Label(shlDatabaseUpload, SWT.NONE);
		lblCountry.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblCountry.setText("Country");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtCountry = new Text(shlDatabaseUpload, SWT.BORDER);
		txtCountry.setText("USA");
		GridData gd_txtCountry = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtCountry.widthHint = 150;
		txtCountry.setLayoutData(gd_txtCountry);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblState = new Label(shlDatabaseUpload, SWT.NONE);
		lblState.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblState.setText("State/Province");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtStateProvince = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtStateProvince = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtStateProvince.widthHint = 150;
		txtStateProvince.setLayoutData(gd_txtStateProvince);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblCounty = new Label(shlDatabaseUpload, SWT.NONE);
		lblCounty.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblCounty.setText("County");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtCounty = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtCounty = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtCounty.widthHint = 150;
		txtCounty.setLayoutData(gd_txtCounty);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblBasin = new Label(shlDatabaseUpload, SWT.NONE);
		lblBasin.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblBasin.setText("Basin");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtBasin = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtBasin = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtBasin.widthHint = 150;
		txtBasin.setLayoutData(gd_txtBasin);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblField = new Label(shlDatabaseUpload, SWT.NONE);
		lblField.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblField.setText("Field");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtField = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtField = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtField.widthHint = 150;
		txtField.setLayoutData(gd_txtField);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		Label lblSurfaceLatitude = new Label(shlDatabaseUpload, SWT.NONE);
		lblSurfaceLatitude.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblSurfaceLatitude.setText("SHL Lat");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		ShlLat = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_ShlLat = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		gd_ShlLat.widthHint = 150;
		ShlLat.setLayoutData(gd_ShlLat);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		Label lblSurfaceLongitude = new Label(shlDatabaseUpload, SWT.NONE);
		lblSurfaceLongitude.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblSurfaceLongitude.setText("SHL Long");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtShlLong = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtShlLong = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtShlLong.widthHint = 150;
		txtShlLong.setLayoutData(gd_txtShlLong);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		Label lblBottomLatitude = new Label(shlDatabaseUpload, SWT.NONE);
		lblBottomLatitude.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblBottomLatitude.setText("BHL Lat");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtBhlLat = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtBhlLat = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtBhlLat.widthHint = 150;
		txtBhlLat.setLayoutData(gd_txtBhlLat);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		Label lblBhlLong = new Label(shlDatabaseUpload, SWT.NONE);
		lblBhlLong.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblBhlLong.setText("BHL Long");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		txtBhlLong = new Text(shlDatabaseUpload, SWT.BORDER);
		GridData gd_txtBhlLong = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtBhlLong.widthHint = 150;
		txtBhlLong.setLayoutData(gd_txtBhlLong);
		
		label_2 = new Label(shlDatabaseUpload, SWT.SEPARATOR | SWT.HORIZONTAL);
		GridData gd_label_2 = new GridData(SWT.FILL, SWT.CENTER, false, false, 4, 1);
		gd_label_2.widthHint = 253;
		label_2.setLayoutData(gd_label_2);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblServices = new Label(shlDatabaseUpload, SWT.NONE);
		lblServices.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		GridData gd_lblServices = new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1);
		gd_lblServices.widthHint = 123;
		lblServices.setLayoutData(gd_lblServices);
		lblServices.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblServices.setText("Services");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblOnsite = new Label(shlDatabaseUpload, SWT.NONE);
		lblOnsite.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblOnsite.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		lblOnsite.setText("Onsite");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblRemote = new Label(shlDatabaseUpload, SWT.NONE);
		lblRemote.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblRemote.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		lblRemote.setText("Remote");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		btnOnsiteGeosteering = new Button(shlDatabaseUpload, SWT.CHECK);
		btnOnsiteGeosteering.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		btnOnsiteGeosteering.setForeground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		btnOnsiteGeosteering.setText("Geosteering");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		btnRemoteGeosteering = new Button(shlDatabaseUpload, SWT.CHECK);
		btnRemoteGeosteering.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		btnRemoteGeosteering.setForeground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		btnRemoteGeosteering.setText("Geosteering");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		btnMudLogging = new Button(shlDatabaseUpload, SWT.CHECK);
		btnMudLogging.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		btnMudLogging.setForeground(SWTResourceManager.getColor(SWT.COLOR_GRAY));

		btnMudLogging.setText("Mud Logging");
		new Label(shlDatabaseUpload, SWT.NONE);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		label_3 = new Label(shlDatabaseUpload, SWT.SEPARATOR | SWT.HORIZONTAL);
		GridData gd_label_3 = new GridData(SWT.FILL, SWT.CENTER, false, false, 4, 1);
		gd_label_3.widthHint = 259;
		label_3.setLayoutData(gd_label_3);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblUploadOptions = new Label(shlDatabaseUpload, SWT.NONE);
		lblUploadOptions.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblUploadOptions.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblUploadOptions.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		lblUploadOptions.setText("Upload Options");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		chkUploadWellInfo = new Button(shlDatabaseUpload, SWT.CHECK);
		chkUploadWellInfo.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		chkUploadWellInfo.setSelection(true);
		chkUploadWellInfo.setText("Well Information");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		chkUploadLogs = new Button(shlDatabaseUpload, SWT.CHECK);
		chkUploadLogs.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		chkUploadLogs.setText("Logs");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		chkUploadSurveys = new Button(shlDatabaseUpload, SWT.CHECK);
		chkUploadSurveys.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		chkUploadSurveys.setText("Survey Data");
		new Label(shlDatabaseUpload, SWT.NONE);
		new Label(shlDatabaseUpload, SWT.NONE);
		new Label(shlDatabaseUpload, SWT.NONE);
		
		lblBeSureApi = new Label(shlDatabaseUpload, SWT.NONE);
		lblBeSureApi.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		lblBeSureApi.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblBeSureApi.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.ITALIC));
		lblBeSureApi.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 3, 1));
		lblBeSureApi.setText("Be sure API and Operator are entered in the survey sheet");
		new Label(shlDatabaseUpload, SWT.NONE);
		
		btnUpload = new Button(shlDatabaseUpload, SWT.BORDER);
		btnUpload.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				btnCancel.setEnabled(false);

				lblUpdateInfo.setText("Uploading to Database. Please Wait");
				uploadToDatabase();
			}
		});
		
		GridData gd_btnUpload = new GridData(SWT.FILL, SWT.CENTER, false, false, 3, 1);
		gd_btnUpload.widthHint = 214;
		btnUpload.setLayoutData(gd_btnUpload);
		btnUpload.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		btnUpload.setForeground(SWTResourceManager.getColor(SWT.COLOR_INFO_BACKGROUND));
		btnUpload.setText("Upload Well to Database");
		
		new Label(shlDatabaseUpload, SWT.NONE);
		
		btnCancel = new Button(shlDatabaseUpload, SWT.BORDER);
		btnCancel.setForeground(SWTResourceManager.getColor(SWT.COLOR_INFO_BACKGROUND));
		btnCancel.setEnabled(true);
		GridData gd_btnCancel = new GridData(SWT.LEFT, SWT.TOP, false, false, 2, 1);
		gd_btnCancel.widthHint = 118;
		btnCancel.setLayoutData(gd_btnCancel);
		btnCancel.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		btnCancel.setText("Cancel");
		btnCancel.addListener(SWT.Selection, new Listener() {
			@Override
			public void handleEvent(Event event)
				{shlDatabaseUpload.close();}});
		
		
		lblUpdateInfo = new Label(shlDatabaseUpload, SWT.NONE);
		GridData gd_lblUpdateInfo = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_lblUpdateInfo.widthHint = 159;
		lblUpdateInfo.setLayoutData(gd_lblUpdateInfo);
		lblUpdateInfo.setFont(SWTResourceManager.getFont("Segoe UI", 7, SWT.BOLD));
		lblUpdateInfo.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_RED));
		lblUpdateInfo.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
	
	}
	
	private void uploadToDatabase()
	{

		try {
			Well well = new Well();
			Formation fm = new Formation();
			String csv = "C:\\Users\\happs\\Desktop\\DatabaseFiles\\Bullhead 721US.csv";

			if(ShlLat.getCharCount() > 0)
				well.setLati(Double.parseDouble(ShlLat.getText()));
			if(txtShlLong.getCharCount() > 0)
				well.setLongi(Double.parseDouble(txtShlLong.getText()));
			if(txtFormation.getCharCount() > 0)
				{fm.setFmName(txtFormation.getText());}
			else fm.setFmName("Unspecified");
			well.setFormation(fm);
			if(txtRigName.getCharCount() > 0)
				well.setRigName(txtRigName.getText());
			
			if (btnOnsiteGeosteering.getSelection())
				if(btnRemoteGeosteering.getSelection())
					well.setService("Remote & Onsite Geosteering & Mudlogging");
				else well.setService("Onsite Geosteering & Mudlogging");
			else if(btnMudLogging.getSelection())
				if(btnRemoteGeosteering.getSelection())
					well.setService("Remote Geosteering & Mudlogging");
				else
					well.setService("Onsite Mudlogging");
			else if(btnRemoteGeosteering.getSelection())
					well.setService("Remote Geosteering");
			else
				well.setService("Unspecified");
			
			String[] people = new String[4];
				people[0] = txtAnalyst1.getText();
				people[1] = txtAnalyst2.getText();
				people[2] = txtAnalyst3.getText();
				people[3] = txtGeologist.getText();

			boolean[] chk = new boolean[3];
				chk[0] = chkUploadWellInfo.getSelection();
				chk[1] = chkUploadLogs.getSelection();
				chk[2] = chkUploadSurveys.getSelection();
				

			ExportService.exportData(well, chk, people, csv);
			
			//NEED ENTRY FOR PROJECT DATA
			
			shlDatabaseUpload.close();
		}catch(Exception e){
			System.out.println("Error");
			e.getMessage();}
	}
}
