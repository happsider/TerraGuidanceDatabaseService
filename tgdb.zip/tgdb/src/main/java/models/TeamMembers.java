package models;

import java.util.ArrayList;
import java.util.List;

public class TeamMembers {
	private List<Person> member = new ArrayList<>();
	private TgTeams team;
	
	public List<Person> getMember() {
		return member;
	}
	public void setMember(List<Person> member) {
		this.member = member;
	}
	public TgTeams getTeam() {
		return team;
	}
	public void setTeam(TgTeams team) {
		this.team = team;
	}
}
