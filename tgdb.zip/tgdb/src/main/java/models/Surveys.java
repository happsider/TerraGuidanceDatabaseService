package models;

import java.util.ArrayList;
import java.util.List;

public class Surveys {
	private String api;
	private int id;
	private List<Double> md  = new ArrayList<>();
	private List<Double> inc = new ArrayList<>();
	private List<Double> azi = new ArrayList<>();
	

	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	public int getId() {
		return id;
	}
	public List<Double> getMd() {
		return md;
	}
	public void setMd(List<Double> md) {
		this.md = md;
	}
	public List<Double> getInc() {
		return inc;
	}
	public void setInc(List<Double> inc) {
		this.inc = inc;
	}
	public List<Double> getAzi() {
		return azi;
	}
	public void setAzi(List<Double> azi) {
		this.azi = azi;
	}
}
