package models;

public class Well {
	private String api, wellName, rigName, service, type, note;
	private double vsAzi, xSurf, ySurf, zSurf, lati, longi, gridId, kb;
	private Formation formation;
	private int siteID;
	
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	public String getWellName() {
		return wellName;
	}
	public void setWellName(String wellName) {
		this.wellName = wellName;
	}
	public String getRigName() {
		return rigName;
	}
	public void setRigName(String rigName) {
		this.rigName = rigName;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}

	public double getVsAzi() {
		return vsAzi;
	}
	public void setVsAzi(double vsAzi) {
		this.vsAzi = vsAzi;
	}
	public double getxSurf() {
		return xSurf;
	}
	public void setxSurf(double xSurf) {
		this.xSurf = xSurf;
	}
	public double getySurf() {
		return ySurf;
	}
	public void setySurf(double ySurf) {
		this.ySurf = ySurf;
	}
	public double getLati() {
		return lati;
	}
	public void setLati(double lati) {
		this.lati = lati;
	}
	public double getLongi() {
		return longi;
	}
	public void setLongi(double longi) {
		this.longi = longi;
	}
	public double getGridId() {
		return gridId;
	}
	public void setGridId(double gridId) {
		this.gridId = gridId;
	}
	public double getzSurf() {
		return zSurf;
	}
	public void setzSurf(double zSurf) {
		this.zSurf = zSurf;
	}
	public int getSiteID() {
		return siteID;
	}
	public void setSiteID(int siteID) {
		this.siteID = siteID;
	}
	public Formation getFormation() {
		return formation;
	}
	public void setFormation(Formation formation) {
		this.formation = formation;
	}
	public double getKb() {
		return kb;
	}
	public void setKb(double kb) {
		this.kb = kb;
	}
}
