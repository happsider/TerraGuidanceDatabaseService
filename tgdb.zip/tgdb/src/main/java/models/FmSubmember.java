package models;

public class FmSubmember {
	private int id;
	private String sbName;
	private Formation formation;
	
	public int getId() {
		return id;
	}
	public String getSbName() {
		return sbName;
	}
	public void setSbName(String sbName) {
		this.sbName = sbName;
	}
	public Formation getFormation() {
		return formation;
	}
	public void setFormation(Formation formation) {
		this.formation = formation;
	}
}
