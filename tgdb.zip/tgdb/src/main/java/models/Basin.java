package models;

public class Basin {
	private int id;
	private String basinName;
	public int getId() {
		return id;
	}
	public String getBasinName() {
		return basinName;
	}
	public void setBasinName(String basinName) {
		this.basinName = basinName;
	}
	
}
