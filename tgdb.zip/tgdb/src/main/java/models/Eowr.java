package models;

public class Eowr {
	private int id;
	private String eowrLink;
	public int getId() {
		return id;
	}
	public String getEowrLink() {
		return eowrLink;
	}
	public void setEowrLink(String eowrLink) {
		this.eowrLink = eowrLink;
	}
}
