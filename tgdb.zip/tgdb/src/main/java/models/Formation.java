package models;

public class Formation {
	private int id;
	private String fmName;
	private Basin basin;
	public int getId() {
		return id;
	}
	public String getFmName() {
		return fmName;
	}
	public void setFmName(String fmName) {
		this.fmName = fmName;
	}
	public Basin getBasin() {
		return basin;
	}
	public void setBasin(Basin basin) {
		this.basin = basin;
	}
}
