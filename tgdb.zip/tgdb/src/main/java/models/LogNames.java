package models;

public class LogNames {
	private String logName;
	private int id;
	
	public int getId() {
		return id;
	}
	public String getLogName() {
		return logName;
	}

	public void setLogName(String logName) {
		this.logName = logName;
	}
}
