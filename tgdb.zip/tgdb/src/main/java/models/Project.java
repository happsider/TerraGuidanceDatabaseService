package models;

public class Project {
	private int id;
	private String state, county, datum, projection;
	private Basin basin;
	public int getId() {
		return id;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getDatum() {
		return datum;
	}
	public void setDatum(String datum) {
		this.datum = datum;
	}
	public String getProjection() {
		return projection;
	}
	public void setProjection(String projection) {
		this.projection = projection;
	}
	public Basin getBasin() {
		return basin;
	}
	public void setBasin(Basin basin) {
		this.basin = basin;
	}

}
