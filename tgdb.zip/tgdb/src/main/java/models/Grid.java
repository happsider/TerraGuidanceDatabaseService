package models;

import java.util.ArrayList;
import java.util.List;

public class Grid {
	private int id;
	private List <Double> xS = new ArrayList<>();
	private List <Double> yS = new ArrayList<>();
	private List <Double> zS = new ArrayList<>();
	
	public int getId() {
		return id;
	}
	public List<Double> getxS() {
		return xS;
	}
	public void setxS(List<Double> xS) {
		this.xS = xS;
	}
	public List<Double> getyS() {
		return yS;
	}
	public void setyS(List<Double> yS) {
		this.yS = yS;
	}
	public List<Double> getzS() {
		return zS;
	}
	public void setzS(List<Double> zS) {
		this.zS = zS;
	}
}
