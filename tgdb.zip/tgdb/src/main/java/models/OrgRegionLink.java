package models;

public class OrgRegionLink {
	private Project region;
	private Organization organization;
	public Project getRegion() {
		return region;
	}
	public void setRegion(Project region) {
		this.region = region;
	}
	public Organization getOrganization() {
		return organization;
	}
	public void setOrganization(Organization organization) {
		this.organization = organization;
	}
}
