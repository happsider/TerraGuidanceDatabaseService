package models;

public class Organization {
	private int id;
	private String orgName, notes;
	private Person primaryContact;
	
	public int getId() {
		return id;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public Person getPrimaryContact() {
		return primaryContact;
	}
	public void setPrimaryContact(Person primaryContact) {
		this.primaryContact = primaryContact;
	}
}
