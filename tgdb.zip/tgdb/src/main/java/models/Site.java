package models;

public class Site {
	private int id;
	private Project region;
	private String padName, rig, field;
	private int xSite, ySite;
	
	public int getId() {
		return id;
	}
	public Project getRegion() {
		return region;
	}
	public void setRegion(Project region) {
		this.region = region;
	}
	public String getPadName() {
		return padName;
	}
	public void setPadName(String padName) {
		this.padName = padName;
	}
	public String getRig() {
		return rig;
	}
	public void setRig(String rig) {
		this.rig = rig;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public int getxSite() {
		return xSite;
	}
	public void setxSite(int xSite) {
		this.xSite = xSite;
	}
	public int getySite() {
		return ySite;
	}
	public void setySite(int ySite) {
		this.ySite = ySite;
	}
}
