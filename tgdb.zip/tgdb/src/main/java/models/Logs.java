package models;

import java.util.ArrayList;
import java.util.List;

public class Logs {
	private int id;
	private String api, name;
	private LogNames logID;
	private Well well;
	private List<Double> md = new ArrayList<>();
	private List<Double> data = new ArrayList<>();
	
	public int getId() {
		return id;
	}
	public Well getWell() {
		return well;
	}
	public void setWell(Well well) {
		this.well = well;
	}
	public List<Double> getMd() {
		return md;
	}
	public void setMd(List<Double> md) {
		this.md = md;
	}
	public List<Double> getData() {
		return data;
	}
	public void setData(List<Double> data) {
		this.data = data;
	}
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LogNames getLogID() {
		return logID;
	}
	public void setLogID(LogNames logID) {
		this.logID = logID;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
