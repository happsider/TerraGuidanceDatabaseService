package models;

import java.util.ArrayList;
import java.util.List;

public class PeopleOnWell {
	private List<Person> person = new ArrayList<>();
	private Well well;
	
	public List<Person> getPerson() {
		return person;
	}
	public void setPerson(List<Person> person) {
		this.person = person;
	}
	public Well getWell() {
		return well;
	}
	public void setWell(Well well) {
		this.well = well;
	}
}
