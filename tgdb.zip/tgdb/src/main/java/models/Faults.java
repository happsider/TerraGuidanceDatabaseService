package models;

public class Faults {
	private int id;
	private Well well;
	private double faultThrow;
	private int md, vs;
	
	public int getId() {
		return id;
	}
	public Well getWell() {
		return well;
	}
	public void setWell(Well well) {
		this.well = well;
	}
	public double getFaultThrow() {
		return faultThrow;
	}
	public void setFaultThrow(double faultThrow) {
		this.faultThrow = faultThrow;
	}
	public int getMd() {
		return md;
	}
	public void setMd(int md) {
		this.md = md;
	}
	public int getVs() {
		return vs;
	}
	public void setVs(int vs) {
		this.vs = vs;
	}
}
